
public class Exercise_4_25c {

	public static void main(String[] args) {
		
		char character = (char)(65+Math.random()*26);
		System.out.print(character);
		character = (char)(65+Math.random()*26);
		System.out.print(character);
		character = (char)(65+Math.random()*26);
		System.out.print(character);
		
		
		byte digit = (byte)(Math.random()*10);
		System.out.print(digit);
		digit = (byte)(Math.random()*10);
		System.out.print(digit);
		digit = (byte)(Math.random()*10);
		System.out.print(digit);
		digit = (byte)(Math.random()*10);
		System.out.print(digit);
	}

}
