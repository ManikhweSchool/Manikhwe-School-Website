import java.util.Scanner;

public class Exercise_5_51a {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		
		
		
		scanner.close();

	}

}
