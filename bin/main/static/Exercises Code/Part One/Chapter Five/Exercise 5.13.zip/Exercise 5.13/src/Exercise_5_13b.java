
public class Exercise_5_13b {

	public static void main(String[] args) {
		
		byte n = 5;

		while(Math.pow(n, 3)<1200) {
			n++;
		}
		
		System.out.print("The value of n is " + n);
		
	}

}
