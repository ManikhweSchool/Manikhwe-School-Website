
public class Exercise_1_9b {

	// At least student B's solution is readable.
	public static void main(String[] args) {
	
		// The + in front of 2 is not acting as an addition operator in this case.
		// Instead it is used to combine/concatenate the string and the value to the right of it.
		System.out.println("The area of a rectangle with wight of 4.5 and height of 7.9 is : " + 4.5*7.9);

	}

}
