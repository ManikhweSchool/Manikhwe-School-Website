
public class Exercise_1_9a {

	// Student A has the most lame solution there is to have.
	public static void main(String[] args) {
		
		System.out.println(4.5*7.9);
		
	}

}
