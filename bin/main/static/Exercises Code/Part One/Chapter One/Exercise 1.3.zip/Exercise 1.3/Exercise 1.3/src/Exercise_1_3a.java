
public class Exercise_1_3a {

	/*Student A uses a grid to plot the pattern.*/
	public static void main(String[] args) {
		
		System.out.println("    J     A     V     V     A");
		System.out.println("    J    A A     V   V     A A");
		System.out.println("J   J   AAAAA     V V     AAAAA");
		System.out.println(" J J   A     A     V     A     A");
		
		/* The pattern is on a grid so, it better to start by drawing a grid.
		 Once a grid is drawn, we start to count spaces between letters.
	     Here we deal with a pattern line by line. Meaning we only count 
		horizontal spaces.
		*/
		
	}

}
