
public class Exercise_1_3c {
	// Student C also do a horizontal reflection of the pattern.
	public static void main(String[] args) {
		
		/* To Find the reflection about the y-axis(Left & Right), is not as easy
		as finding the reflection about the x-axis(Up & Down). To find the reflection
		about the y-axis(Left & Right) you do it line by line using a grid. Note J cannot
		be reflected.*/
		
		System.out.println("    J     A     V     V     A        A     V     V     A     J");
		System.out.println("    J    A A     V   V     A A      A A     V   V     A A    J");
		System.out.println("J   J   AAAAA     V V     AAAAA    AAAAA     V V     AAAAA   J   J");
		System.out.println(" J J   A     A     V     A     A  A     A     V     A     A   J J");
		
		
		
	}

}
