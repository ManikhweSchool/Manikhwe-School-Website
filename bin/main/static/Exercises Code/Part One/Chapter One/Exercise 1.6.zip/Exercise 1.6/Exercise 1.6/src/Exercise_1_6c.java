public class Exercise_1_6c {

	// Student C has a more readable solution.
	public static void main(String[] args) {
		
System.out.print("The sum of the first nine positive integers is " + 1+2+3+4+5+6+7+8+9);

	}

}
