
public class Exercise_1_2a {

	// Student A used println which is a straight forward approach.
	public static void main(String[] args) {
		
		System.out.println("Welcome to Java");
		System.out.println("Welcome to Java");
		System.out.println("Welcome to Java");
		System.out.println("Welcome to Java");
		System.out.println("Welcome to Java");
		
	}

}
