
public class Exercise_1_2b {

	// Student B shows the effect of putting something inside the quotes.
	public static void main(String[] args) {

		System.out.print("**********Welcome to Java**********");
		System.out.println();
		System.out.print("**********Welcome to Java**********");
		System.out.println();
		System.out.print("**********Welcome to Java**********");
		System.out.println();
		System.out.print("**********Welcome to Java**********");
		System.out.println();
		System.out.println("**********Welcome to Java**********");
	}

}
