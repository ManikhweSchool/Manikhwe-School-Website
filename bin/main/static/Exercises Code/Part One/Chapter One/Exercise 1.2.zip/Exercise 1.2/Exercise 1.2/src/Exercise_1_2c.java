
public class Exercise_1_2c {

	// Student C shows that you can manipulate the output in whatever way you please.
	public static void main(String[] args) {
		
		// Put ten arrows at the beginning and end of the string.
		System.out.print(">>>>>>>>>>Welcome to Java<<<<<<<<<<");
		// Put eight arrows at the beginning and end of the string.
		System.out.print("\n>>>>>>>>Welcome to Java<<<<<<<<");
		// Put six arrows at the beginning and end of the string.
        System.out.print("\n>>>>>>Welcome to Java<<<<<<");		
		// Put four arrows at the beginning and end of the string.
		System.out.print("\n>>>>Welcome to Java<<<<");		
		// Put two arrows at the beginning and end of the string.
		System.out.print("\n>>Welcome to Java<<");
		
		// Create space
		System.out.print("\n\n\n");
		
		// Put ten hash tags at the beginning and end of the string.
		System.out.println("\n##Welcome to Java##");
		// Put eight hash tags at the beginning and end of the string.
		System.out.println("####Welcome to Java####");
		// Put six hash tags at the beginning and end of the string.
        System.out.println("######Welcome to Java######");		
		// Put four hash tags at the beginning and end of the string.
		System.out.println("########Welcome to Java########");		
		// Put two hash tags at the beginning and end of the string.
		System.out.println("##########Welcome to Java##########");
		
		
		// The lesson here is that what ever you put inside "" will affect your output.
	}

}
