
public class Exercise_1_1b {

	// Student B used the combination of println and print.
	public static void main(String[] args) {
				
		System.out.print("Welcome to Java.");
		System.out.println();
		System.out.print("Welcome to Computer Science.");
		System.out.println();
		System.out.print("Programming is fun.");
		
	}
}
