
public class Exercise_1_1a {
	
	// Student A used the most obvious approach.
	public static void main(String[] args) {
		
		System.out.println("Welcome to Java.");
		System.out.println("Welcome to Computer Science.");
		System.out.println("Programming is fun.");
	}
}
