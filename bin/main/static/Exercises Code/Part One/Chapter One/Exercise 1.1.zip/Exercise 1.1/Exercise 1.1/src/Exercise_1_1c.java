
public class Exercise_1_1c {

	// Student C uses the fact that \n can work as println.
	public static void main(String[] args) {
				
		System.out.print("Welcome to Java.\nWelcome to Computer Science.\nProgramming is fun.");
	}
}
