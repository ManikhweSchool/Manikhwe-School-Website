weightInKilograms = eval(input('Enter weight : '))

print('There are', weightInKilograms*2.2,'pound(s) in',
weightInKilograms,'kilogram(s).')
