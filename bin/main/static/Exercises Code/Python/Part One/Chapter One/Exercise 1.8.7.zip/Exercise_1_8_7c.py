kilograms = eval(input('Enter weight : '))
pounds = kilograms*2.2
print('There are',round(pounds,2),'pounds(s) in',kilograms,'kilogram(s).')
