x = eval(input('Enter x : '))
print(x,2*x,3*x,4*x,sep='---')
