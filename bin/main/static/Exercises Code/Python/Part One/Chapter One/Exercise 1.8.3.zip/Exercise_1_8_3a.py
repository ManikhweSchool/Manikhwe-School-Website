print('*')
print('**')
print('***')
print('****')
