numerator = 512-282
denominator = 47*48+5

print(numerator/denominator)
