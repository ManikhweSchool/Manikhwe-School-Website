numerator = 512-282
denominator = 47*48+5
answer = numerator/denominator

print('Answer =',round(answer,4))
