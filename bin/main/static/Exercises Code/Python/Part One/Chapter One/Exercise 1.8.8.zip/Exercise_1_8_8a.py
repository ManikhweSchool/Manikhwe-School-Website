number1 = eval(input('Enter number1 : '))
number2 = eval(input('Enter number2 : '))
number3 = eval(input('Enter number3 : '))

total = number1+number2+number3
average = total/3

print('Total =',total)
print('Average =',average)
