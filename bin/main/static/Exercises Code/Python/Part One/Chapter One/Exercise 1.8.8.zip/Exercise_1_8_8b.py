value1 = eval(input('Enter Value1 : '))
value2 = eval(input('Enter Value2 : '))
value3 = eval(input('Enter Value3 : '))

total = value1
total = total + value2
total = total + value3

average = total
average = average/3

print('Total =',total)
print('Average =', average)
