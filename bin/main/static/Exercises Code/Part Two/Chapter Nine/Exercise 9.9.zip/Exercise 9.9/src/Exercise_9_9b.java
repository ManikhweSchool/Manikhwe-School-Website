
public class Exercise_9_9b {

	public static void main(String[] args) {
		
		RegularPolygon1 regularPolygon1 = new RegularPolygon1();
		RegularPolygon1 regularPolygon2 = new RegularPolygon1(6,4);
		RegularPolygon1 regularPolygon3 = new RegularPolygon1(10,4, 5.6, 7.8);

		System.out.printf("Polygon 1 Area : %5.2f\tPerimeter : %5.2f\n", 
		regularPolygon1.getArea(),regularPolygon1.getPerimeter());
		
		System.out.printf("Polygon 2 Area : %5.2f\tPerimeter : %5.2f\n", 
		regularPolygon2.getArea(),regularPolygon2.getPerimeter());
		
		System.out.printf("Polygon 3 Area : %5.2f\tPerimeter : %5.2f\n", 
		regularPolygon3.getArea(),regularPolygon3.getPerimeter());
	}

}
