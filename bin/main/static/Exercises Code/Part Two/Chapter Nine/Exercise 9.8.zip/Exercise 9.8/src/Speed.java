
public enum Speed {

	SLOW, MEDIUM, FAST
}
