
public class Exercise_9_8b {

	public static void main(String[] args) {
		
		
		Fan yellowFan = new Fan();
		yellowFan.setColor("yellow");
		yellowFan.setRadius(10);
		yellowFan.setOn(true);
		yellowFan.setSpeed(Speed.FAST);
		
		Fan blueFan = new Fan();
		blueFan.setSpeed(Speed.MEDIUM);
		
		System.out.println(yellowFan);
		System.out.println(blueFan);
	}

}
