
public class Exercise_5_12b {

	public static void main(String[] args) {
		
		int n = 1;
		
		while(n*n <= 12000) 
			n++;
		
		
		System.out.print("The value of n is " + n +
		" and n squared is " + n*n);
	}
}
