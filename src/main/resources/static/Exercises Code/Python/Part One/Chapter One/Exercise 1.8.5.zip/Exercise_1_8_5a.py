number = eval(input('Enter a number : '))
print('The square of ',number,' is ',number*number,'.',sep='')
