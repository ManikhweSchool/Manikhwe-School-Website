import java.util.Scanner;

public class Exercise_9_11b {

	public static void main(String[] args) {
		
		// Create scanner
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("Enter a,b,c,d,e,f : ");
		double a = scanner.nextDouble();
		double b = scanner.nextDouble();
		double c = scanner.nextDouble();
		double d = scanner.nextDouble();
		double e = scanner.nextDouble();
		double f = scanner.nextDouble();
		
		LinearEquation linearEquation1 = 
		new LinearEquation(a,b,c,d,e,f);
		
		LinearEquation linearEquation2 = 
		new LinearEquation(
		linearEquation1.getA(),
		linearEquation1.getB(),
		linearEquation1.getC(),
		linearEquation1.getD(),
		linearEquation1.getE(),
		linearEquation1.getF());
		
		if(linearEquation1.isSolvable()) {
			System.out.printf("x = %3.2f\ny = %3.2f\n\n", 
			linearEquation1.getX(),linearEquation1.getY());
		}
		else
			System.out.println("The equation has no solution.\n");
		
		linearEquation2.displayResult();
		
		// Close scanner
		scanner.close();

	}

}
