import java.util.Scanner;

public class QuadraticEquation {

	private double a,b,c;
	
	public QuadraticEquation(double a, double b, double c) {
		this.a = a;
		this.b =  b;
		this.c = c;
	}
	
	public double getRoot1() {
		
		double discriminant = getDiscriminant();
		if(discriminant>=0)
			return ((-b + Math.sqrt(discriminant))/(2*a));
		return 0;	
	}
	
	public double getRoot2() {
		
		double discriminant = getDiscriminant();
		if(discriminant>=0)
			return ((-b - Math.sqrt(discriminant))/(2*a));
		return 0;	
	}
	
	public double getDiscriminant() {
		return b*b-4*a*c;
	}

	public double getA() {
		return a;
	}

	public double getB() {
		return b;
	}

	public double getC() {
		return c;
	}
	
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("Enter a, b, and c : ");
		double a = scanner.nextDouble();
		double b = scanner.nextDouble();
		double c = scanner.nextDouble();
		
		QuadraticEquation quadraticEquation = 
		new QuadraticEquation(a,b,c);
		
		if(quadraticEquation.getDiscriminant()>0)
			System.out.printf("Root 1 : %5.2f\tRoot 2 : %5.2f",
			quadraticEquation.getRoot1(),quadraticEquation.getRoot2());
		else if(quadraticEquation.getDiscriminant()==0)
			System.out.printf("Root 1 : %5.2f",
			quadraticEquation.getRoot1());
		else
			System.out.print("The equation has no root.");
		
		scanner.close();
	}
}
